#!/bin/bash

# Diretório onde as receitas ficam salvas localmente no sistema
DEST_DIR="/usr/share/ospkg/receita"
TEMP_DIR="/tmp/ospkg_update_temp"

echo "-> Atualizando repositório de receitas..."

# Cria uma pasta temporária limpa
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"

# Entra na pasta temporária
cd "$TEMP_DIR" || exit 1

# Inicializa um repositório git vazio, adiciona o remoto e faz o sparse-checkout só da pasta 'receitas'
git init
git remote add origin https://github.com/linux-oxy-retro-cyber/ospkg.git
git config core.sparseCheckout true

# Diz pro git que só queremos a pasta receitas/
echo "receitas/" >> .git/info/sparse-checkout

echo "-> Baixando receitas mais recentes do GitHub..."
# Faz o download apenas da branch main (depth 1 para ser rápido e leve)
git pull origin main --depth 1

# Verifica se a pasta baixada realmente existe
if [ -d "receitas" ]; then
    # Garante que o destino existe
    sudo mkdir -p "$DEST_DIR"
    
    # Remove as receitas antigas para evitar lixo
    sudo rm -rf "${DEST_DIR:?}"/*
    
    # Copia tudo o que está dentro da pasta baixada para a pasta de receitas do sistema
    sudo cp -r receitas/* "$DEST_DIR/"
    
    echo "-> Receitas atualizadas com sucesso!"
else
    echo "Erro: Não foi possível encontrar a pasta de receitas no repositório."
    exit 1
fi

# Limpa a sujeira da pasta temporária
rm -rf "$TEMP_DIR"