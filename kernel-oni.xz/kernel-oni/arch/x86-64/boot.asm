bits 32
global start
extern kernel_main

section .multiboot_header
align 8
header_start:
    dd 0xe85250d6                ; Magic number (Multiboot2)
    dd 0                         ; Arquitetura: 0 (modo protegido i386)
    dd header_end - header_start ; Tamanho do cabeçalho
    dd -(0xe85250d6 + 0 + (header_end - header_start)) ; Checksum

    ; Tag de término
    dw 0
    dw 0
    dd 8
header_end:

section .bss
align 4096
p4_table:
    resb 4096
p3_table:
    resb 4096
p2_table:
    resb 4096
stack_bottom:
    resb 16384                  ; Stack de 16 KiB
stack_top:

section .rodata
gdt64:
    dq 0                        ; Entrada nula
.code_segment: equ $ - gdt64
    dq (1<<43) | (1<<44) | (1<<47) | (1<<53) ; Segmento de código 64-bit
.pointer:
    dw $ - gdt64 - 1
    dq gdt64

section .text
start:
    mov esp, stack_top

    ; Configura paginação de identidade simples (2 MiB)
    mov eax, p3_table
    or eax, 0b11                 ; Presente + Escrita
    mov [p4_table], eax

    mov eax, p2_table
    or eax, 0b11
    mov [p3_table], eax

    mov eax, 0b10000011          ; Presente + Escrita + Page Size (2MiB)
    mov [p2_table], eax

    ; Ativa PAE na CR4
    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    ; Carrega P4 no CR3
    mov eax, p4_table
    mov cr3, eax

    ; Ativa Modo Longo no MSR de EFER
    mov ecx, 0xc0000080
    rdmsr
    or eax, 1 << 8
    wrmsr

    ; Ativa Paginação no CR0
    mov eax, cr0
    or eax, 1 << 31
    mov cr0, eax

    ; Carrega a GDT de 64 bits
    lgdt [gdt64.pointer]

    ; Salta para o segmento de código de 64 bits
    jmp gdt64.code_segment:long_mode_start

bits 64
long_mode_start:
    ; Reseta os registradores de segmento
    mov ax, 0
    mov ss, ax
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    call kernel_main
    cli
.halt:
    hlt
    jmp .halt