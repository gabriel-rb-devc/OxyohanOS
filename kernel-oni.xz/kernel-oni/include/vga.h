#ifndef vga
#define vga

void limpar_azul(void);

void kprint(const char *message);

#endif
