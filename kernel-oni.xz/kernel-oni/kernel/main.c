#include "../include/vga.h"
#define cinza 0x7F
#define azul 0x1F

void seilar(void)
{
volatile char *lsa = (volatile char*)0xb8000;
for (int i = 0; i < 80 * 25 * 2; i += 2)
{
    lsa[i] = ' ';
    lsa[i + 1] = 0x8F;
}

}

void kernel_main(){
    seilar();
//limpar_azul();
/*kprint("kernel panic exit code: 0xb8000 nao e frameburfe.\n");
kprint("          ##                  \n");
kprint("        ### %%@      #%       \n");
kprint("       #######@########       \n");
kprint("       :% %   #########       \n");
kprint("       #@@-* =#######         \n");
kprint("      #####%########          \n");
kprint("  :%%:%############           \n");
kprint(" :  :: %=.%@#####:            \n");
kprint("      ##@@@######%            \n");
kprint("       ###########            \n");
kprint("         @#######@            \n");
kprint("         ######::#            \n");
kprint("          @@#@##@##%          \n");
kprint("     %@*-+-@-+%+ * .#####%    \n");
kprint("vai logo me mata com esse seu pc velho com esse i3 merda");
*/
}

