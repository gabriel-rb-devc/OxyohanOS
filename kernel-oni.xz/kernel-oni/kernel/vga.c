/*
este e um drive simples feito com ninha paciencia e gemini pra me dizer onde eu tava errando
*/
#include "../include/vga.h"
void limpar_azul(void){
    volatile char *vga_buffer = (volatile char *)0xb8000;
    // Limpa a tela colocando espaço e cor azul estranho claro sobre preto
    for (int i = 0; i < 80 * 25 * 2; i += 2) { // essa ea formula de de tamanho de tela vga 80 por 25
        vga_buffer[i] = ' '; // imprime um caracteri nulo sem nada ou espaço ja que ha um caracteri
        vga_buffer[i + 1] = 0x1F; // pinta o fundo de azul passando mas um caracteri que eo de cor apenas
        
        }
}


void kprint(const char *message) {
    volatile char *vga_buffer = (volatile char *)0xb8000; // 0xb8000 eo endereço de video vga 
    static int offset = 0; // inicia a variavel de ofset
    
 
    for (int i = 0; message[i] != '\0'; i++) { // inicio do for de repetiçao
        if (message[i] == '\n') // verifica se ha \n se sim ele pula uma linha no offset ou de endereço de vga
        {
         offset = (offset/160 + 1) * 160;  // pula uma linha essa ea maldita formula 
        }
        else{
        vga_buffer[offset] = message[i];      // Caractere
        vga_buffer[offset + 1] = 0x1F;        // Cor: Branco brilhante
        offset += 2; // pra pular para uma casa apenas isso 
        }
}
}
